# RuangKita — Template Katalog Produk UMKM

Template katalog produk responsif berbasis HTML, CSS, dan JavaScript murni.

## Fitur
- Responsif untuk HP dan desktop
- Pencarian produk
- Filter kategori
- Keranjang dengan pengaturan jumlah
- Hitung total pesanan
- Pesan melalui WhatsApp
- Tanpa framework, database, atau backend

## Cara menjalankan
1. Ekstrak ZIP.
2. Buka `index.html` menggunakan browser atau fitur Preview di editor kode Android.
3. Koneksi internet tidak diperlukan untuk fitur katalog dasar; koneksi diperlukan untuk membuka WhatsApp.

## Cara menyesuaikan
- Edit array `products` di bagian JavaScript untuk mengubah nama, deskripsi, kategori, emoji, dan harga produk.
- Ganti `WHATSAPP_NUMBER` dengan nomor pemilik toko dalam format internasional tanpa tanda plus, misalnya `62812xxxxxxx`.
- Ganti nama toko, teks, dan warna di CSS sesuai kebutuhan.
- Emoji produk adalah ilustrasi demo; ganti dengan gambar produk milik klien bila tersedia.

## Batasan
- Ini adalah template frontend, bukan sistem e-commerce penuh.
- Tidak ada pembayaran online, akun pengguna, database, stok otomatis, atau panel admin.
- Data keranjang hanya tersimpan selama halaman dibuka.
- Pastikan semua harga, informasi, gambar, dan nomor kontak benar sebelum digunakan untuk bisnis nyata.

## Lisensi untuk penjual
Tentukan sendiri lisensi penggunaan saat menjual template. Pastikan kamu memiliki hak atas semua kode, gambar, font, dan aset yang disertakan. Jangan menjanjikan fitur yang belum tersedia.
